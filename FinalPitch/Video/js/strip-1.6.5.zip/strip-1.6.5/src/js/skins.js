Strip.Skins = {
  // the default skin
  'strip': { }
};
