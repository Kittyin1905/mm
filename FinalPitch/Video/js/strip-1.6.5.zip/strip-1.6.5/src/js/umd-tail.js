// start
$(document).ready(function(event) {
  _Strip.initialize();
});

return Strip;

}));
